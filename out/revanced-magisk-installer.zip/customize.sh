SKIPUNZIP=1
URL="https://github.com/HuskyDG/revanced-build-ci/releases/download/latest/revanced-magisk.zip"

# stub module installer

ui_print "- Download module..."
ping -c 1 google.com &>/dev/null || abort "! No internet connection"
wget "$URL" -O "$TMPDIR/revanced-magisk.zip" || abort "! Download failed"

ui_print "- Extracting module files"
unzip -o "$TMPDIR/revanced-magisk.zip" -x customize.sh -d "$MODPATH" &>/dev/null
mkdir -p "$TMPDIR/installer"
unzip -o "$TMPDIR/revanced-magisk.zip" customize.sh -d "$TMPDIR/installer" &>/dev/null
ui_print "- YouTube version: $(grep_prop version "$MODPATH/module.prop")"
. "$TMPDIR/installer/customize.sh"